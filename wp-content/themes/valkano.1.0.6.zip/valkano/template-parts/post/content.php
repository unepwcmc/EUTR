<?php
/**
 * Template part for displaying posts
 * @package Valkano
 * @version 1.0.6
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<div class="post-wrapper">
		<?php if( has_category()):
				echo '<ul class="meta-top"><li class="meta-categories list-inline-item">';
					the_category();
				echo '</li></ul>';
		endif; ?>
		<header class="entry-header">
			<?php the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' ); ?>
		</header>

		<?php if ( has_post_thumbnail() ) : ?>
            <div class="post-thumbnail">
                <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
            </div><!-- .post-thumbnail -->
        <?php endif; ?>

		<ul class="entry-meta meta-center list-inline">
			
				<li class="author list-inline-item">
					<span class="author vcard">
						<a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' )) ); ?>"><?php the_author(); ?></a>
					</span>
				</li>
				<li class="posted-on list-inline-item">
					<?php $post_time = valkano_time_link(); esc_html( $post_time ); ?>
				</li>
			
			<li class="meta-comment list-inline-item">
				<?php $cmt_link = get_comments_link(); 
					  $num_comments = get_comments_number();
						if ( $num_comments == 0 ) {
							$comments = __( 'No Comments', 'valkano' );
						} elseif ( $num_comments > 1 ) {
							$comments = $num_comments . __( ' Comments', 'valkano' );
						} else {
							$comments = __('1 Comment', 'valkano' );
						}
				?>	
				<a href="<?php echo esc_url( $cmt_link ); ?>"><?php echo esc_html( $comments );?></a>
			</li>
		</ul>
        
        <div class="entry-content">
			<?php the_excerpt(); ?>
        </div><!-- .entry-content -->
		
    </div>
</article><!-- #post-## -->
