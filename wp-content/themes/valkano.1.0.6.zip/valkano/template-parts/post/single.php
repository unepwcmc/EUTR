<?php
/**
 * Template part for displaying posts
 * @package Valkano
 * @version 1.0.6
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<div class="post-wrapper">
	
		<header class="entry-header">
            
            <?php the_title( '<h2 class="entry-title">', '</h2>' ); ?>
        
        	<ul class="entry-meta list-inline">
                <li class="author list-inline-item">
					<span class="author vcard">
						<a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' )) ); ?>"><?php the_author(); ?></a>
					</span>
				</li>
				<li class="posted-on list-inline-item">
					<?php $post_time = valkano_time_link(); esc_html( $post_time ); ?>
				</li>
				<li class="meta-comment list-inline-item">
                    <?php $cmt_link = get_comments_link(); 
						  $num_comments = get_comments_number();
							if ( $num_comments == 0 ) {
								$comments = __( 'No Comments', 'valkano' );
							} elseif ( $num_comments > 1 ) {
								$comments = $num_comments . __( ' Comments', 'valkano' );
							} else {
								$comments = __('1 Comment', 'valkano' );
							}
					?>	
                    <a href="<?php echo esc_url( $cmt_link ); ?>"><?php echo esc_html( $comments );?></a>
                </li>
                
			</ul>
        
        </header><!-- .entry-header -->
		
		<?php if ( has_post_thumbnail() ) : ?>
            <div class="post-thumbnail">
                <?php the_post_thumbnail( 'full' ); ?>
            </div>
		<?php endif; ?>
        
        <div class="entry-content">
			<?php the_content(); ?>
		</div><!-- .entry-content -->
		<?php if( has_tag() ) { ?>
		<div class="meta-bottom post-tags">
			<?php the_tags(); ?>
		</div>
		<?php } ?>
	</div>
</article><!-- #post-## -->
