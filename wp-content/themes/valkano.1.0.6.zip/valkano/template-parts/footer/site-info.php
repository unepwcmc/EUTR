<?php
/**
 * Displays footer site info
 *
 * @package Valkano
 * @version 1.0.6
 */

?>

<div class="site-info">
	<?php $copyright_text = valkano_get_option( 'copyright_text' ); 
    
        if ( ! empty( $copyright_text ) ) : ?>
    
            <p><?php echo wp_kses_data( $copyright_text ); ?></p> 
    
    <?php endif; ?>
        <a href="<?php echo esc_url( __( 'http://www.pioneerthemes.com/', 'valkano' ) ); ?>">
			<?php /* translators: %s: author name. */ ?>
			<?php printf( esc_html__( 'Designed by %s', 'valkano' ), 'Pioneerthemes' ); ?>
		</a>
</div><!-- .site-info -->
