<?php
/**
 * Displays header site branding
 *
 * @package Valkano
 * @version 1.0.6
 */

?>
<?php
$header_status = valkano_get_option( 'show_top_header' );
	if ( 1 == $header_status ) {
		
			$top_address    = valkano_get_option( 'top_address' );
			$top_phone      = valkano_get_option( 'top_phone' );
			$top_email      = valkano_get_option( 'top_email' );
			$facebook_link  = valkano_get_option( 'facebook_link' );
			$twitter_link  = valkano_get_option( 'twitter_link' );
			$instagram_link  = valkano_get_option( 'instagram_link' );
			$google_link  = valkano_get_option( 'google_link' );

			$left_section  	= valkano_get_option( 'left_section' );
			$right_section  = valkano_get_option( 'right_section' );

			?>
            
            <div class="col-md-6">
                <div class="header-left">
    
                    <?php 
                    if( 'contact' == $left_section && ( !empty( $top_address ) || !empty( $top_phone ) || !empty( $top_email ) ) ){ ?>
    
                        <ul class="contact-info list-inline">
                            <?php if( !empty( $top_address ) ){ ?>
                                <li class="address list-inline-item">
                                	<i class="fa fa-map-marker" aria-hidden="true"></i> 
									<p><?php echo esc_html( $top_address ); ?></p>
                                </li>
                            <?php } ?>
    
                            <?php if( !empty( $top_phone ) ){ ?>
                                <li class="phone list-inline-item">
                                	<i class="fa fa-phone" aria-hidden="true"></i>
                                    <p><?php echo esc_html( $top_phone ); ?></p>
                                </li>
                            <?php } ?>
    
                            <?php if( !empty( $top_email ) ){ ?>
                                <li class="email list-inline-item">
                                	<i class="fa fa-envelope-o" aria-hidden="true"></i>
                                        <a href="mailto:<?php echo esc_url( $top_email ); ?>">
                                            <?php echo esc_html( sanitize_email(  $top_email ) ); ?>
                                        </a>
                                </li>
                            <?php } ?>
                            
                        </ul>
                        <?php
                    } elseif( 'top-social' == $left_section &&  ( !empty( $facebook_link ) || !empty( $twitter_link ) || !empty( $instagram_link ) || !empty( $google_link ) )){ ?>
    
                        <ul class="social-info list-inline">
                            <?php if( !empty( $facebook_link ) ){ ?>
                                <li class="facebook list-inline-item">
                                	<a href="<?php echo esc_url( $facebook_link ); ?>">
                                    	<i class="fa fa-facebook" aria-hidden="true"></i>
                                   	</a>
                                </li>
                            <?php } ?>
    
                            <?php if( !empty( $twitter_link ) ){ ?>
                                <li class="twitter list-inline-item">
                                	<a href="<?php echo esc_url( $twitter_link ); ?>">
                                    	<i class="fa fa-twitter" aria-hidden="true"></i>
                                   	</a>
                                </li>
                            <?php } ?>
    
                            <?php if( !empty( $instagram_link ) ){ ?>
                                <li class="instagram list-inline-item">
                                	<a href="<?php echo esc_url( $instagram_link ); ?>">
                                    	<i class="fa fa-instagram" aria-hidden="true"></i>
                                   	</a>
                                </li>
                            <?php } ?>
                            <?php if( !empty( $google_link ) ){ ?>
                                <li class="google list-inline-item">
                                	<a href="<?php echo esc_url( $google_link ); ?>">
                                    	<i class="fa fa-google-plus" aria-hidden="true"></i> 
                                   	</a>
                                </li>
                            <?php } ?>
                            
                        </ul>
                        <?php
                    } ?>
                </div><!-- .header-left -->
            </div>
            <div class="col-md-6">
                <div class="header-right">
    
                    <?php 
                    if( 'contact' == $right_section && ( !empty( $top_address ) || !empty( $top_phone ) || !empty( $top_email ) ) ){ ?>
    
                        <ul class="contact-info list-inline">
                            <?php if( !empty( $top_address ) ){ ?>
                                <li class="address list-inline-item">
                                	<i class="fa fa-map-marker" aria-hidden="true"></i>
									<p><?php echo esc_html( $top_address ); ?></p>
                                 </li>
                            <?php } ?>
    
                            <?php if( !empty( $top_phone ) ){ ?>
                                <li class="phone list-inline-item">
                                	<i class="fa fa-phone" aria-hidden="true"></i> 
									<p><?php echo esc_html( $top_phone ); ?></p>
                                </li>
                            <?php } ?>
    
                            <?php if( !empty( $top_email ) ){ ?>
                                <li class="email list-inline-item"><i class="fa fa-envelope-o" aria-hidden="true"></i>
									<a href="mailto:<?php echo esc_url( $top_email ); ?>">
										<?php echo esc_html( sanitize_email( $top_email ) ); ?>
                                    </a>
								</li>
                            <?php } ?>
                            
                        </ul>
                        <?php
                    }  elseif('top-social' == $right_section &&  ( !empty( $facebook_link ) || !empty( $twitter_link ) || !empty( $instagram_link ) || !empty( $google_link ) )){ ?>
    
                        <ul class="social-info list-inline">
                            <?php if( !empty( $facebook_link ) ){ ?>
                                <li class="facebook list-inline-item">
                                	<a href="<?php echo esc_url( $facebook_link ); ?>">
                                    	<i class="fa fa-facebook" aria-hidden="true"></i>
                                   	</a>
                                </li>
                            <?php } ?>
    
                            <?php if( !empty( $twitter_link ) ){ ?>
                                <li class="twitter list-inline-item">
                                	<a href="<?php echo esc_url( $twitter_link ); ?>">
                                    	<i class="fa fa-twitter" aria-hidden="true"></i>
                                   	</a>
                                </li>
                            <?php } ?>
    
                            <?php if( !empty( $instagram_link ) ){ ?>
                                <li class="instagram list-inline-item">
                                	<a href="<?php echo esc_url( $instagram_link ); ?>">
                                    	<i class="fa fa-instagram" aria-hidden="true"></i>
                                   	</a>
                                </li>
                            <?php } ?>
                            <?php if( !empty( $google_link ) ){ ?>
                                <li class="google list-inline-item">
                                	<a href="<?php echo esc_url( $google_link ); ?>">
                                    	<i class="fa fa-google-plus" aria-hidden="true"></i> 
                                   	</a>
                                </li>
                            <?php } ?>
                            
                        </ul>
					<?php } ?>
                </div><!-- .header-right -->
            </div>

<?php } ?>
