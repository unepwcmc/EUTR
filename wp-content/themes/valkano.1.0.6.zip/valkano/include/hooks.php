<?php
if( ! function_exists('valkano_related_post_action')){

	function valkano_related_post_action(){
		$p_id = get_the_ID();
		$categories = get_the_category( get_the_ID() );
		foreach( $categories as $individual_category ) { 
				$category_ids[] = $individual_category->term_id;
		}
		$args = array(
				'category__in' => $category_ids,
				'post__not_in' => array( $p_id ),
				'posts_per_page'=> 3,
				'post_status' => 'publish',
				'orderby' => 'rand',
		);
		$related_query = new wp_query( $args );
		if( $related_query->have_posts() ){ ?>
			<div class="related-post">
				<div class="row">
					<div class="col-lg-12">
						<h3 class="related-title"><?php esc_html_e( 'Related Posts', 'valkano' ); ?></h3>
					</div>
				</div>
				<div class="row">
					<?php while( $related_query->have_posts() ){
						$related_query->the_post(); ?>
						<div class="col-lg-4">
							<div class="post-item post">
								<?php if ( has_post_thumbnail() ) : ?>
									<div class="image-wrap">
										<div class="post-thumbnail">
											<?php the_post_thumbnail('valkano-related-post-thumb'); ?>
										</div>
									</div>
								<?php endif; ?>
								<div class="content-wrap">
									<?php the_title( '<h3 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h3>' ); ?>
									<ul class="entry-meta list-inline">
										<li class="author list-inline-item">
											<span class="author vcard">
												<a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' )) ); ?>"><?php the_author(); ?></a>
											</span>
										</li>
										<li class="posted-on list-inline-item">
											<?php $post_time = valkano_time_link(); esc_html( $post_time ); ?>
										</li>
										<li class="meta-comment list-inline-item">
											<?php $cmt_link = get_comments_link(); 
												  $num_comments = get_comments_number();
													if ( $num_comments == 0 ) {
														$comments = __( 'No Comments', 'valkano' );
													} elseif ( $num_comments > 1 ) {
														$comments = $num_comments . __( ' Comments', 'valkano' );
													} else {
														$comments = __('1 Comment', 'valkano' );
													}
											?>	
											<a href="<?php echo esc_url( $cmt_link ); ?>"><?php echo esc_html( $comments );?></a>
										</li>
									</ul>
									<div class="entry-bottom">
										<a href="<?php echo esc_url( get_permalink() );?>" class="read-more btn">
											<?php esc_html_e( 'Read More', 'valkano' ); ?>
											<i class="fa fa-long-arrow-right" aria-hidden="true"></i>
										</a>
									</div>
								</div>
							</div>
						</div>
					<?php }  ?>
				</div>
			</div>
		<?php } wp_reset_query();
		
	}
}
add_action('valkano_related_post', 'valkano_related_post_action');
?>