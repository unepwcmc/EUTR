<?php
/*--------------------------------------------------------------------*/
/*     Register Google Fonts
/*--------------------------------------------------------------------*/
function valkano_fonts_url() {
	
    $fonts_url = '';
		
    $font_families = array();
 
	$font_families = array('Playfair Display:400,700&subset=latin,latin-ext|Poppins:300,400,500,600,700&subset=latin,latin-ext|Marck Script');
 
        $query_args = array(
            'family' => urlencode( implode( '|', $font_families ) ),
            'subset' => urlencode( 'latin,latin-ext' ),
        );
 
        $fonts_url = add_query_arg( $query_args, '//fonts.googleapis.com/css' );

    return esc_url_raw($fonts_url);
}
function valkano_scripts_styles() {
    wp_enqueue_style( 'google-fonts', valkano_fonts_url(), array(), null );
}
add_action( 'wp_enqueue_scripts', 'valkano_scripts_styles' );
?>